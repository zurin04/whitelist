import { Request, Response, NextFunction } from 'express';
import { storage } from './storage';
import crypto from 'crypto';
import bcrypt from 'bcrypt';

export interface AuthenticatedRequest extends Request {
  adminId?: number;
}

export async function hashPassword(password: string): Promise<string> {
  return await bcrypt.hash(password, 10);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return await bcrypt.compare(password, hash);
}

export function generateToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

export async function adminAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  
  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  try {
    const session = await storage.getAdminSession(token);
    
    if (!session || session.expiresAt < new Date()) {
      if (session) {
        await storage.deleteAdminSession(token);
      }
      return res.status(401).json({ error: 'Invalid or expired token' });
    }

    req.adminId = session.adminId;
    next();
  } catch (error) {
    console.error('Admin auth error:', error);
    res.status(500).json({ error: 'Authentication error' });
  }
}