import { getDefaultConfig } from '@rainbow-me/rainbowkit';
import { mainnet, polygon, optimism, arbitrum, base } from 'wagmi/chains';

export const config = getDefaultConfig({
  appName: 'zaihash.xyz',
  projectId: import.meta.env.VITE_WALLETCONNECT_PROJECT_ID || 'zaihash-default-project-id',
  chains: [mainnet, polygon, optimism, arbitrum, base],
  ssr: false,
});

export const createSignMessage = (address: string) => {
  return `Welcome to zaihash.xyz!

Click to sign in and verify your wallet ownership.

This request will not trigger a blockchain transaction or cost any gas fees.

Wallet address: ${address}
Timestamp: ${new Date().toISOString()}`;
};
