import { useEffect } from 'react';
import WhitelistForm from '@/components/whitelist-form';
import PartnersSection from '@/components/partners-section';

const Home = () => {
  useEffect(() => {
    // Add gradient background animation
    const hero = document.querySelector('.hero-section');
    if (hero) {
      hero.classList.add('animate-pulse');
    }
  }, []);

  return (
    <section className="min-h-screen relative overflow-hidden">
      {/* Subtle background overlay for better text contrast */}
      <div className="absolute inset-0 bg-gradient-to-br from-black/80 via-gray-900/60 to-black/80" />
      
      {/* Very subtle animated grid background */}
      <div className="absolute inset-0 opacity-5">
        <div className="grid-background"></div>
      </div>
      
      {/* Hero Section */}
      <div className="relative z-10 pt-20 pb-16 hero-section">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight text-white">
              <span className="gradient-text">
                Welcome to zaihash
              </span>
              <br />
              <span className="text-white">
                Join the Whitelist
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              A cutting-edge Web3 platform for exclusive access to decentralized opportunities. 
              Connect your wallet and secure your spot in the next generation of blockchain innovation.
            </p>
          </div>

          {/* Whitelist Registration Form */}
          <div className="max-w-md mx-auto">
            <WhitelistForm />
          </div>
        </div>
      </div>

      {/* Partners and Backers Section */}
      <PartnersSection />

      {/* Subtle floating particles effect */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-cyan-400/20 rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${3 + Math.random() * 4}s`,
            }}
          />
        ))}
      </div>
    </section>
  );
};

export default Home;
