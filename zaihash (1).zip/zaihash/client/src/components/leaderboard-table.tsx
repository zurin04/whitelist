import { useEffect } from 'react';
import { Trophy, Medal, Award } from 'lucide-react';
import { anonymizeWallet } from '@/lib/validation';
import { useReferrals } from '@/hooks/use-referrals';

const LeaderboardTable = () => {
  const { leaderboard, stats, refreshData } = useReferrals();

  useEffect(() => {
    refreshData();
  }, []);

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="w-6 h-6 text-yellow-400" />;
      case 2:
        return <Medal className="w-6 h-6 text-gray-300" />;
      case 3:
        return <Award className="w-6 h-6 text-orange-400" />;
      default:
        return (
          <div className="w-8 h-8 bg-gray-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
            {rank}
          </div>
        );
    }
  };

  const getStatusBadge = (referralCount: number) => {
    if (referralCount >= 100) {
      return (
        <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-neon-green/20 text-neon-green">
          Champion
        </span>
      );
    } else if (referralCount >= 50) {
      return (
        <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-neon-blue/20 text-neon-blue">
          Elite
        </span>
      );
    } else if (referralCount >= 25) {
      return (
        <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-neon-purple/20 text-neon-purple">
          Pro
        </span>
      );
    } else {
      return (
        <span className="inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-gray-500/20 text-gray-300">
          Active
        </span>
      );
    }
  };

  return (
    <div className="space-y-8">
      {/* Leaderboard Table */}
      <div className="glassmorphism rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-[hsl(var(--deep-space))]/50">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-300 uppercase tracking-wider">
                  Rank
                </th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-300 uppercase tracking-wider">
                  Wallet Address
                </th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-300 uppercase tracking-wider">
                  Referrals
                </th>
                <th className="px-6 py-4 text-left text-sm font-medium text-gray-300 uppercase tracking-wider">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-500/20">
              {leaderboard.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-6 py-8 text-center text-gray-400">
                    No referrals yet. Be the first to refer someone!
                  </td>
                </tr>
              ) : (
                leaderboard.map(({ walletAddress, referralCount }, index) => (
                  <tr
                    key={walletAddress}
                    className="hover:bg-white/5 transition-colors"
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        {getRankIcon(index + 1)}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-mono text-gray-300">
                        {anonymizeWallet(walletAddress)}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-bold text-neon-blue">
                        {referralCount}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {getStatusBadge(referralCount)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid md:grid-cols-3 gap-6">
        <div className="glassmorphism rounded-xl p-6 text-center">
          <div className="text-3xl font-bold text-neon-blue mb-2">
            {stats.totalReferrals}
          </div>
          <p className="text-gray-400">Total Referrals</p>
        </div>
        <div className="glassmorphism rounded-xl p-6 text-center">
          <div className="text-3xl font-bold text-neon-green mb-2">
            {stats.activeReferrers}
          </div>
          <p className="text-gray-400">Active Referrers</p>
        </div>
        <div className="glassmorphism rounded-xl p-6 text-center">
          <div className="text-3xl font-bold text-neon-purple mb-2">
            {stats.totalWhitelisted}
          </div>
          <p className="text-gray-400">Whitelist Size</p>
        </div>
      </div>
    </div>
  );
};

export default LeaderboardTable;
