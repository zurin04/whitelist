import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAccount } from 'wagmi';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Rocket, CheckCircle, AlertCircle } from 'lucide-react';
import { whitelistFormSchema, WhitelistFormData } from '@/lib/validation';
import { useWhitelist } from '@/hooks/use-whitelist';
import { useWallet } from '@/hooks/use-wallet';

const WhitelistForm = () => {
  const { address } = useAccount();
  const { signIn, isSigningIn } = useWallet();
  const { addEntry, isLoading, isUserWhitelisted } = useWhitelist();
  const [showSuccess, setShowSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<WhitelistFormData>({
    resolver: zodResolver(whitelistFormSchema),
  });

  // Auto-fill wallet address when connected
  useEffect(() => {
    if (address) {
      setValue('walletAddress', address);
    }
  }, [address, setValue]);

  // Check if user is already whitelisted
  const walletAddress = watch('walletAddress');
  const isAlreadyWhitelisted = walletAddress && isUserWhitelisted(walletAddress);

  const onSubmit = async (data: WhitelistFormData) => {
    setErrorMessage('');
    setShowSuccess(false);

    // Check if wallet is connected and signed in
    if (!address) {
      setErrorMessage('Please connect your wallet first');
      return;
    }

    // Sign message for verification
    const signedIn = await signIn();
    if (!signedIn) {
      return;
    }

    // Get referrer from URL params
    const urlParams = new URLSearchParams(window.location.search);
    const referrer = urlParams.get('ref');

    const success = await addEntry({
      name: data.name,
      email: data.email,
      walletAddress: data.walletAddress,
      referrer: referrer || undefined,
    });

    if (success) {
      setShowSuccess(true);
      // Redirect to whitelist page after success
      setTimeout(() => {
        window.location.href = '/whitelist';
      }, 2000);
    }
  };

  if (isAlreadyWhitelisted) {
    return (
      <div className="glassmorphism rounded-2xl p-8 shadow-2xl">
        <div className="text-center">
          <CheckCircle className="w-16 h-16 text-neon-green mx-auto mb-4" />
          <h3 className="text-2xl font-bold text-neon-green mb-4">
            You're Already Whitelisted!
          </h3>
          <p className="text-gray-300 mb-6">
            This wallet address is already registered in our whitelist.
          </p>
          <Button
            onClick={() => window.location.href = '/whitelist'}
            className="gradient-bg hover:scale-105 transition-transform"
          >
            View Your Status
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="glassmorphism rounded-2xl p-8 shadow-2xl">
      <h3 className="text-2xl font-bold text-center mb-6" style={{ color: 'white' }}>
        Join the Whitelist
      </h3>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* Name Field */}
        <div>
          <Label htmlFor="name" className="text-gray-200" style={{ color: 'white', fontWeight: 'bold' }}>
            Full Name
          </Label>
          <Input
            id="name"
            {...register('name')}
            className="mt-2 glassmorphism border-gray-500/30 text-white placeholder-gray-400 focus:ring-2 focus:ring-neon-blue focus:border-transparent"
            placeholder="Enter your full name"
          />
          {errors.name && (
            <p className="text-red-400 text-sm mt-1">{errors.name.message}</p>
          )}
        </div>

        {/* Email Field */}
        <div>
          <Label htmlFor="email" className="text-gray-200" style={{ color: 'white', fontWeight: 'bold' }}>
            Email Address
          </Label>
          <Input
            id="email"
            type="email"
            {...register('email')}
            className="mt-2 glassmorphism border-gray-500/30 text-white placeholder-gray-400 focus:ring-2 focus:ring-neon-blue focus:border-transparent"
            placeholder="your.email@example.com"
          />
          {errors.email && (
            <p className="text-red-400 text-sm mt-1">{errors.email.message}</p>
          )}
        </div>

        {/* Wallet Address Field */}
        <div>
          <Label htmlFor="walletAddress" className="text-gray-200" style={{ color: 'white', fontWeight: 'bold' }}>
            Wallet Address
          </Label>
          <Input
            id="walletAddress"
            {...register('walletAddress')}
            className="mt-2 glassmorphism border-gray-500/30 text-white placeholder-gray-400 focus:ring-2 focus:ring-neon-blue focus:border-transparent"
            placeholder="0x..."
            readOnly={!!address}
          />
          {errors.walletAddress && (
            <p className="text-red-400 text-sm mt-1">
              {errors.walletAddress.message}
            </p>
          )}
          {!address && (
            <p className="text-gray-400 text-sm mt-1">
              Connect your wallet to auto-fill this field
            </p>
          )}
        </div>

        {/* Error Message */}
        {errorMessage && (
          <Alert className="bg-red-500/20 border-red-500/30 text-red-200">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{errorMessage}</AlertDescription>
          </Alert>
        )}

        {/* Success Message */}
        {showSuccess && (
          <Alert className="bg-neon-green/20 border-neon-green/30 text-green-200">
            <CheckCircle className="h-4 w-4" />
            <AlertDescription>
              Successfully joined the whitelist! Redirecting...
            </AlertDescription>
          </Alert>
        )}

        {/* Submit Button */}
        <Button
          type="submit"
          disabled={isLoading || isSigningIn}
          className="w-full gradient-bg futuristic-btn text-white py-3 px-6 rounded-lg font-medium transition-all duration-300 flex items-center justify-center"
        >
          <Rocket className="mr-2 h-5 w-5" />
          {isLoading ? 'Joining...' : isSigningIn ? 'Signing...' : 'Join Whitelist'}
        </Button>
      </form>
    </div>
  );
};

export default WhitelistForm;
