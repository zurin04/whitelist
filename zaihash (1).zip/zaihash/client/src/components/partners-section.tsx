import { useEffect, useState } from 'react';

const PartnersSection = () => {
  const [partnerLogos, setPartnerLogos] = useState<string[]>([]);

  // Generate random partner logos on component mount
  useEffect(() => {
    const generateLogos = () => {
      const logos = [];
      for (let i = 0; i < 8; i++) {
        // Generate random geometric logos using SVG
        const colors = ['#00ffff', '#ff00ff', '#ffff00', '#00ff80', '#ff8000', '#8000ff'];
        const randomColor = colors[Math.floor(Math.random() * colors.length)];
        const shapes = ['circle', 'rect', 'polygon'];
        const randomShape = shapes[Math.floor(Math.random() * shapes.length)];
        
        let shapeElement = '';
        if (randomShape === 'circle') {
          shapeElement = `<circle cx="50" cy="50" r="30" fill="${randomColor}" opacity="0.8"/>`;
        } else if (randomShape === 'rect') {
          shapeElement = `<rect x="20" y="20" width="60" height="60" rx="10" fill="${randomColor}" opacity="0.8"/>`;
        } else {
          shapeElement = `<polygon points="50,15 85,80 15,80" fill="${randomColor}" opacity="0.8"/>`;
        }
        
        const svg = `
          <svg width="100" height="100" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <filter id="glow${i}">
                <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
                <feMerge>
                  <feMergeNode in="coloredBlur"/>
                  <feMergeNode in="SourceGraphic"/>
                </feMerge>
              </filter>
            </defs>
            ${shapeElement}
            <text x="50" y="55" font-family="Arial, sans-serif" font-size="12" fill="white" text-anchor="middle" filter="url(#glow${i})">LOGO</text>
          </svg>
        `;
        
        const blob = new Blob([svg], { type: 'image/svg+xml' });
        const url = URL.createObjectURL(blob);
        logos.push(url);
      }
      setPartnerLogos(logos);
    };

    generateLogos();
    
    // Cleanup URLs on unmount
    return () => {
      partnerLogos.forEach(url => URL.revokeObjectURL(url));
    };
  }, []);

  const partnerNames = [
    'TechFlow Ventures',
    'Quantum Capital',
    'CyberSync Labs',
    'NeoFusion Corp',
    'Digital Nexus',
    'FutureLink Systems',
    'ByteStorm Industries',
    'MetaCore Solutions'
  ];

  const backerNames = [
    'BlockChain Ventures',
    'Crypto Capital',
    'Web3 Investments',
    'DeFi Partners',
    'Innovation Fund',
    'Tech Accelerator'
  ];

  return (
    <section className="py-20 relative">
      {/* Background overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/20 to-transparent" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Partners Section */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 gradient-text">
            Our Partners
          </h2>
          <p className="text-gray-300 text-lg">
            Trusted by industry leaders and innovative companies
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-20">
          {partnerLogos.slice(0, 8).map((logo, index) => (
            <div 
              key={index}
              className="glassmorphism rounded-xl p-6 flex flex-col items-center justify-center hover:scale-105 transition-transform duration-300"
            >
              <div className="w-16 h-16 mb-3 blur-sm">
                <img 
                  src={logo} 
                  alt={`Partner ${index + 1}`} 
                  className="w-full h-full object-contain"
                />
              </div>
              <span className="text-gray-300 text-sm text-center blur-sm">
                {partnerNames[index]}
              </span>
            </div>
          ))}
        </div>

        {/* Backers Section */}
        <div className="text-center mb-12">
          <h3 className="text-2xl md:text-3xl font-bold mb-4 gradient-text">
            Backed By
          </h3>
          <p className="text-gray-300">
            Supported by leading investors in the Web3 space
          </p>
        </div>

        <div className="flex flex-wrap justify-center items-center gap-8">
          {backerNames.map((name, index) => (
            <div 
              key={index}
              className="glassmorphism rounded-lg px-6 py-3 hover:neon-glow transition-all duration-300"
            >
              <span className="text-gray-300 font-medium blur-sm">
                {name}
              </span>
            </div>
          ))}
        </div>

        {/* Stats Section */}
        <div className="grid md:grid-cols-3 gap-8 mt-16">
          <div className="text-center">
            <div className="text-4xl font-bold text-neon-blue mb-2">50+</div>
            <p className="text-gray-400">Strategic Partners</p>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-neon-green mb-2">$10M+</div>
            <p className="text-gray-400">Total Funding</p>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold text-neon-purple mb-2">25+</div>
            <p className="text-gray-400">Investment Rounds</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PartnersSection;