#!/usr/bin/env node

import readline from 'readline';
import bcrypt from 'bcrypt';
import { Pool } from '@neondatabase/serverless';

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

async function question(prompt) {
  return new Promise((resolve) => {
    rl.question(prompt, resolve);
  });
}

async function createAdmin() {
  console.log('🔐 Admin User Creation Script for zaihash.xyz');
  console.log('This will create an admin user for the admin dashboard.\n');

  try {
    // Get database connection
    const pool = new Pool({ connectionString: process.env.DATABASE_URL });
    
    // Get admin credentials
    const username = await question('Enter admin username: ');
    const password = await question('Enter admin password: ');
    
    if (!username || !password) {
      console.log('❌ Username and password are required.');
      process.exit(1);
    }

    if (password.length < 6) {
      console.log('❌ Password must be at least 6 characters long.');
      process.exit(1);
    }

    // Check if user already exists
    const existingUser = await pool.query(
      'SELECT id FROM users WHERE username = $1',
      [username]
    );

    if (existingUser.rows.length > 0) {
      console.log('❌ Username already exists.');
      process.exit(1);
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create admin user (need a dummy wallet address for the required field)
    const dummyWallet = '0x0000000000000000000000000000000000000000';
    await pool.query(
      'INSERT INTO users (username, password, wallet_address, is_admin, created_at) VALUES ($1, $2, $3, $4, NOW())',
      [username, hashedPassword, dummyWallet, true]
    );

    console.log('✅ Admin user created successfully!');
    console.log(`Username: ${username}`);
    console.log('You can now login to the admin dashboard at: https://admin.zaihash.xyz');
    
  } catch (error) {
    console.error('❌ Error creating admin user:', error.message);
    process.exit(1);
  } finally {
    rl.close();
  }
}

createAdmin();