import { whitelistEntries, referralData, type WhitelistEntry, type InsertWhitelistEntry, type ReferralData, type InsertReferralData } from "@shared/schema";

// Storage interface for whitelist and referral functionality
export interface IStorage {
  // Whitelist operations
  getWhitelistEntries(): Promise<WhitelistEntry[]>;
  getWhitelistEntryByEmail(email: string): Promise<WhitelistEntry | undefined>;
  getWhitelistEntryByWallet(walletAddress: string): Promise<WhitelistEntry | undefined>;
  createWhitelistEntry(entry: InsertWhitelistEntry): Promise<WhitelistEntry>;
  
  // Referral operations
  getReferralData(walletAddress: string): Promise<ReferralData | undefined>;
  updateReferralCount(walletAddress: string, count: number): Promise<ReferralData>;
  incrementReferralCount(walletAddress: string): Promise<ReferralData>;
  getLeaderboard(): Promise<ReferralData[]>;
}

export class MemStorage implements IStorage {
  private whitelistEntries: Map<number, WhitelistEntry>;
  private referralData: Map<string, ReferralData>;
  private currentWhitelistId: number;
  private currentReferralId: number;

  constructor() {
    this.whitelistEntries = new Map();
    this.referralData = new Map();
    this.currentWhitelistId = 1;
    this.currentReferralId = 1;
  }

  async getWhitelistEntries(): Promise<WhitelistEntry[]> {
    return Array.from(this.whitelistEntries.values());
  }

  async getWhitelistEntryByEmail(email: string): Promise<WhitelistEntry | undefined> {
    return Array.from(this.whitelistEntries.values()).find(
      entry => entry.email.toLowerCase() === email.toLowerCase()
    );
  }

  async getWhitelistEntryByWallet(walletAddress: string): Promise<WhitelistEntry | undefined> {
    return Array.from(this.whitelistEntries.values()).find(
      entry => entry.walletAddress.toLowerCase() === walletAddress.toLowerCase()
    );
  }

  async createWhitelistEntry(insertEntry: InsertWhitelistEntry): Promise<WhitelistEntry> {
    const id = this.currentWhitelistId++;
    const entry: WhitelistEntry = {
      id,
      name: insertEntry.name,
      email: insertEntry.email,
      walletAddress: insertEntry.walletAddress,
      referrer: insertEntry.referrer ?? null,
      timestamp: new Date(),
    };
    this.whitelistEntries.set(id, entry);
    return entry;
  }

  async getReferralData(walletAddress: string): Promise<ReferralData | undefined> {
    return this.referralData.get(walletAddress.toLowerCase());
  }

  async updateReferralCount(walletAddress: string, count: number): Promise<ReferralData> {
    const existing = this.referralData.get(walletAddress.toLowerCase());
    const data: ReferralData = existing 
      ? { ...existing, referralCount: count }
      : { id: this.currentReferralId++, walletAddress, referralCount: count };
    
    this.referralData.set(walletAddress.toLowerCase(), data);
    return data;
  }

  async incrementReferralCount(walletAddress: string): Promise<ReferralData> {
    const existing = this.referralData.get(walletAddress.toLowerCase());
    const newCount = existing ? existing.referralCount + 1 : 1;
    return this.updateReferralCount(walletAddress, newCount);
  }

  async getLeaderboard(): Promise<ReferralData[]> {
    return Array.from(this.referralData.values())
      .sort((a, b) => b.referralCount - a.referralCount);
  }
}

export const storage = new MemStorage();
