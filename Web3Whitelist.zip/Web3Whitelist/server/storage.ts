import {
  whitelistEntries,
  referralData,
  users,
  adminSessions,
  type WhitelistEntry,
  type InsertWhitelistEntry,
  type UpdateWhitelistEntry,
  type ReferralData,
  type InsertReferralData,
  type User,
  type InsertUser,
  type AdminSession,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // User/Admin operations
  getUserByWallet(walletAddress: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createAdminSession(adminId: number, token: string, expiresAt: Date): Promise<AdminSession>;
  getAdminSession(token: string): Promise<AdminSession | undefined>;
  deleteAdminSession(token: string): Promise<void>;
  
  // Whitelist operations
  getWhitelistEntries(): Promise<WhitelistEntry[]>;
  getWhitelistEntryByEmail(email: string): Promise<WhitelistEntry | undefined>;
  getWhitelistEntryByWallet(walletAddress: string): Promise<WhitelistEntry | undefined>;
  createWhitelistEntry(entry: InsertWhitelistEntry): Promise<WhitelistEntry>;
  updateWhitelistEntry(id: number, update: UpdateWhitelistEntry): Promise<WhitelistEntry>;
  deleteWhitelistEntry(id: number): Promise<void>;
  
  // Referral operations
  getReferralData(walletAddress: string): Promise<ReferralData | undefined>;
  updateReferralCount(walletAddress: string, count: number): Promise<ReferralData>;
  incrementReferralCount(walletAddress: string): Promise<ReferralData>;
  getLeaderboard(): Promise<ReferralData[]>;
}

export class DatabaseStorage implements IStorage {
  // User/Admin operations
  async getUserByWallet(walletAddress: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.walletAddress, walletAddress));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async createAdminSession(adminId: number, token: string, expiresAt: Date): Promise<AdminSession> {
    const [session] = await db.insert(adminSessions).values({
      adminId,
      token,
      expiresAt,
    }).returning();
    return session;
  }

  async getAdminSession(token: string): Promise<AdminSession | undefined> {
    const [session] = await db.select().from(adminSessions).where(eq(adminSessions.token, token));
    return session;
  }

  async deleteAdminSession(token: string): Promise<void> {
    await db.delete(adminSessions).where(eq(adminSessions.token, token));
  }

  // Whitelist operations
  async getWhitelistEntries(): Promise<WhitelistEntry[]> {
    return await db.select().from(whitelistEntries).orderBy(desc(whitelistEntries.timestamp));
  }

  async getWhitelistEntryByEmail(email: string): Promise<WhitelistEntry | undefined> {
    const [entry] = await db.select().from(whitelistEntries).where(eq(whitelistEntries.email, email));
    return entry;
  }

  async getWhitelistEntryByWallet(walletAddress: string): Promise<WhitelistEntry | undefined> {
    const [entry] = await db.select().from(whitelistEntries).where(eq(whitelistEntries.walletAddress, walletAddress));
    return entry;
  }

  async createWhitelistEntry(entry: InsertWhitelistEntry): Promise<WhitelistEntry> {
    const [newEntry] = await db.insert(whitelistEntries).values(entry).returning();
    return newEntry;
  }

  async updateWhitelistEntry(id: number, update: UpdateWhitelistEntry): Promise<WhitelistEntry> {
    const [updatedEntry] = await db
      .update(whitelistEntries)
      .set({ ...update, updatedAt: new Date() })
      .where(eq(whitelistEntries.id, id))
      .returning();
    return updatedEntry;
  }

  async deleteWhitelistEntry(id: number): Promise<void> {
    await db.delete(whitelistEntries).where(eq(whitelistEntries.id, id));
  }

  // Referral operations
  async getReferralData(walletAddress: string): Promise<ReferralData | undefined> {
    const [data] = await db.select().from(referralData).where(eq(referralData.walletAddress, walletAddress));
    return data;
  }

  async updateReferralCount(walletAddress: string, count: number): Promise<ReferralData> {
    const existing = await this.getReferralData(walletAddress);
    
    if (existing) {
      const [updated] = await db
        .update(referralData)
        .set({ referralCount: count })
        .where(eq(referralData.walletAddress, walletAddress))
        .returning();
      return updated;
    } else {
      const [newData] = await db
        .insert(referralData)
        .values({ walletAddress, referralCount: count })
        .returning();
      return newData;
    }
  }

  async incrementReferralCount(walletAddress: string): Promise<ReferralData> {
    const existing = await this.getReferralData(walletAddress);
    const newCount = existing ? existing.referralCount + 1 : 1;
    return this.updateReferralCount(walletAddress, newCount);
  }

  async getLeaderboard(): Promise<ReferralData[]> {
    return await db.select().from(referralData).orderBy(desc(referralData.referralCount));
  }
}

export const storage = new DatabaseStorage();