import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { adminAuth, hashPassword, verifyPassword, generateToken, type AuthenticatedRequest } from "./adminAuth";
import { 
  insertWhitelistEntrySchema, 
  updateWhitelistEntrySchema, 
  loginSchema,
  insertUserSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Admin authentication routes
  app.post('/api/admin/login', async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(username);
      if (!user || !user.isAdmin) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      const isValid = await verifyPassword(password, user.password);
      if (!isValid) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      const token = generateToken();
      const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
      
      await storage.createAdminSession(user.id, token, expiresAt);
      
      res.json({ 
        token, 
        user: { 
          id: user.id, 
          username: user.username, 
          isAdmin: user.isAdmin 
        } 
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ error: 'Login failed' });
    }
  });

  app.post('/api/admin/logout', adminAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const token = req.headers.authorization?.replace('Bearer ', '');
      if (token) {
        await storage.deleteAdminSession(token);
      }
      res.json({ message: 'Logged out successfully' });
    } catch (error) {
      res.status(500).json({ error: 'Logout failed' });
    }
  });

  // Admin user creation (for initial setup)
  app.post('/api/admin/create', async (req, res) => {
    try {
      const { username, password } = insertUserSchema.parse(req.body);
      
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ error: 'Username already exists' });
      }

      const hashedPassword = await hashPassword(password);
      const user = await storage.createUser({
        username,
        password: hashedPassword,
        isAdmin: true,
      });

      res.json({ 
        message: 'Admin created successfully',
        user: { id: user.id, username: user.username, isAdmin: user.isAdmin }
      });
    } catch (error) {
      console.error('Create admin error:', error);
      res.status(500).json({ error: 'Failed to create admin' });
    }
  });

  // Public whitelist routes
  app.get('/api/whitelist', async (req, res) => {
    try {
      const entries = await storage.getWhitelistEntries();
      res.json(entries);
    } catch (error) {
      console.error('Get whitelist error:', error);
      res.status(500).json({ error: 'Failed to fetch whitelist entries' });
    }
  });

  app.post('/api/whitelist', async (req, res) => {
    try {
      const entryData = insertWhitelistEntrySchema.parse(req.body);
      
      // Check if email or wallet already exists
      const existingEmail = await storage.getWhitelistEntryByEmail(entryData.email);
      if (existingEmail) {
        return res.status(400).json({ error: 'Email already registered' });
      }

      const existingWallet = await storage.getWhitelistEntryByWallet(entryData.walletAddress);
      if (existingWallet) {
        return res.status(400).json({ error: 'Wallet already registered' });
      }

      const entry = await storage.createWhitelistEntry(entryData);
      
      // Increment referrer count if referrer exists
      if (entryData.referrer) {
        await storage.incrementReferralCount(entryData.referrer);
      }

      res.json(entry);
    } catch (error) {
      console.error('Create whitelist error:', error);
      res.status(400).json({ error: 'Failed to create whitelist entry' });
    }
  });

  // Admin whitelist management routes
  app.get('/api/admin/whitelist', adminAuth, async (req, res) => {
    try {
      const entries = await storage.getWhitelistEntries();
      res.json(entries);
    } catch (error) {
      console.error('Admin get whitelist error:', error);
      res.status(500).json({ error: 'Failed to fetch whitelist entries' });
    }
  });

  app.patch('/api/admin/whitelist/:id', adminAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updateData = updateWhitelistEntrySchema.parse(req.body);
      
      const updatedEntry = await storage.updateWhitelistEntry(id, updateData);
      res.json(updatedEntry);
    } catch (error) {
      console.error('Admin update whitelist error:', error);
      res.status(500).json({ error: 'Failed to update whitelist entry' });
    }
  });

  app.delete('/api/admin/whitelist/:id', adminAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteWhitelistEntry(id);
      res.json({ message: 'Entry deleted successfully' });
    } catch (error) {
      console.error('Admin delete whitelist error:', error);
      res.status(500).json({ error: 'Failed to delete whitelist entry' });
    }
  });

  // Referral routes
  app.get('/api/referrals/leaderboard', async (req, res) => {
    try {
      const leaderboard = await storage.getLeaderboard();
      res.json(leaderboard);
    } catch (error) {
      console.error('Get leaderboard error:', error);
      res.status(500).json({ error: 'Failed to fetch leaderboard' });
    }
  });

  app.get('/api/referrals/:walletAddress', async (req, res) => {
    try {
      const { walletAddress } = req.params;
      const referralData = await storage.getReferralData(walletAddress);
      res.json(referralData || { walletAddress, referralCount: 0 });
    } catch (error) {
      console.error('Get referral data error:', error);
      res.status(500).json({ error: 'Failed to fetch referral data' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
