import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  walletAddress: text("wallet_address").notNull().unique(),
  isAdmin: boolean("is_admin").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const whitelistEntries = pgTable("whitelist_entries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  walletAddress: text("wallet_address").notNull().unique(),
  referrer: text("referrer"),
  status: text("status").default("pending").notNull(), // pending, approved, rejected
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const adminSessions = pgTable("admin_sessions", {
  id: serial("id").primaryKey(),
  adminId: integer("admin_id").notNull(),
  token: text("token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const referralData = pgTable("referral_data", {
  id: serial("id").primaryKey(),
  walletAddress: text("wallet_address").notNull().unique(),
  referralCount: integer("referral_count").default(0).notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const web3LoginSchema = z.object({
  walletAddress: z.string().regex(/^0x[a-fA-F0-9]{40}$/, "Invalid wallet address"),
  signature: z.string().min(1, "Signature is required"),
  message: z.string().min(1, "Message is required"),
});

export const insertWhitelistEntrySchema = createInsertSchema(whitelistEntries).omit({
  id: true,
  timestamp: true,
  updatedAt: true,
}).extend({
  name: z.string().min(2, "Name must be at least 2 characters").max(100, "Name too long"),
  email: z.string().email("Invalid email format"),
  walletAddress: z.string().regex(/^0x[a-fA-F0-9]{40}$/, "Invalid wallet address format"),
  referrer: z.string().regex(/^0x[a-fA-F0-9]{40}$/, "Invalid referrer address").optional().nullable(),
  status: z.enum(["pending", "approved", "rejected"]).optional(),
});

export const updateWhitelistEntrySchema = z.object({
  status: z.enum(["pending", "approved", "rejected"]),
});

export const insertReferralDataSchema = createInsertSchema(referralData).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Web3LoginData = z.infer<typeof web3LoginSchema>;
export type WhitelistEntry = typeof whitelistEntries.$inferSelect;
export type InsertWhitelistEntry = z.infer<typeof insertWhitelistEntrySchema>;
export type UpdateWhitelistEntry = z.infer<typeof updateWhitelistEntrySchema>;
export type ReferralData = typeof referralData.$inferSelect;
export type InsertReferralData = z.infer<typeof insertReferralDataSchema>;
export type AdminSession = typeof adminSessions.$inferSelect;
