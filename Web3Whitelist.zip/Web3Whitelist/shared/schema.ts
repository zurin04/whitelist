import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const whitelistEntries = pgTable("whitelist_entries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  walletAddress: text("wallet_address").notNull().unique(),
  referrer: text("referrer"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const referralData = pgTable("referral_data", {
  id: serial("id").primaryKey(),
  walletAddress: text("wallet_address").notNull().unique(),
  referralCount: integer("referral_count").default(0).notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertWhitelistEntrySchema = createInsertSchema(whitelistEntries).omit({
  id: true,
  timestamp: true,
}).extend({
  name: z.string().min(2, "Name must be at least 2 characters").max(100, "Name too long"),
  email: z.string().email("Invalid email format"),
  walletAddress: z.string().regex(/^0x[a-fA-F0-9]{40}$/, "Invalid wallet address format"),
  referrer: z.string().regex(/^0x[a-fA-F0-9]{40}$/, "Invalid referrer address").optional().nullable(),
});

export const insertReferralDataSchema = createInsertSchema(referralData).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type WhitelistEntry = typeof whitelistEntries.$inferSelect;
export type InsertWhitelistEntry = z.infer<typeof insertWhitelistEntrySchema>;
export type ReferralData = typeof referralData.$inferSelect;
export type InsertReferralData = z.infer<typeof insertReferralDataSchema>;
