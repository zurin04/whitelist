import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAdminAuth } from "@/hooks/use-admin-auth";
import Navbar from "@/components/navbar";
import Home from "@/pages/home";
import Whitelist from "@/pages/whitelist";
import Leaderboard from "@/pages/leaderboard";
import AdminLogin from "@/pages/admin-login";
import AdminDashboard from "@/pages/admin-dashboard";
import NotFound from "@/pages/not-found";

function AdminRoute({ component: Component }: { component: React.ComponentType }) {
  const { isAuthenticated, isLoading } = useAdminAuth();
  
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }
  
  if (!isAuthenticated) {
    return <AdminLogin />;
  }
  
  return <Component />;
}

function Router() {
  // Check if we're on admin subdomain
  const isAdminDomain = window.location.hostname.startsWith('admin.');
  
  if (isAdminDomain) {
    return (
      <div className="min-h-screen">
        <Switch>
          <Route path="/login" component={AdminLogin} />
          <Route path="/dashboard" component={() => <AdminRoute component={AdminDashboard} />} />
          <Route path="/" component={() => <AdminRoute component={AdminDashboard} />} />
          <Route component={NotFound} />
        </Switch>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[hsl(var(--deep-space))] text-white">
      <Navbar />
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/whitelist" component={Whitelist} />
        <Route path="/leaderboard" component={Leaderboard} />
        <Route component={NotFound} />
      </Switch>
    </div>
  );
}

function App() {
  return (
    <TooltipProvider>
      <Toaster />
      <Router />
    </TooltipProvider>
  );
}

export default App;
