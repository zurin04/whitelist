import { useState, useEffect } from 'react';
import { LocalStorage } from '@/lib/storage';
import { useToast } from '@/hooks/use-toast';

export const useReferrals = () => {
  const [referralData, setReferralData] = useState<{[key: string]: number}>({});
  const [leaderboard, setLeaderboard] = useState<Array<{ walletAddress: string; referralCount: number }>>([]);
  const [stats, setStats] = useState({
    totalWhitelisted: 0,
    totalReferrals: 0,
    activeReferrers: 0,
  });
  const { toast } = useToast();

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    setReferralData(LocalStorage.getReferralData());
    setLeaderboard(LocalStorage.getLeaderboard());
    setStats(LocalStorage.getTotalStats());
  };

  const getReferralCount = (walletAddress: string) => {
    return referralData[walletAddress] || 0;
  };

  const getReferralLink = (walletAddress: string) => {
    return `${window.location.origin}/?ref=${walletAddress}`;
  };

  const copyReferralLink = async (walletAddress: string) => {
    try {
      const link = getReferralLink(walletAddress);
      await navigator.clipboard.writeText(link);
      toast({
        title: "Link copied!",
        description: "Your referral link has been copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Failed to copy",
        description: "Please copy the link manually",
        variant: "destructive",
      });
    }
  };

  const shareOnTwitter = (walletAddress: string) => {
    const link = getReferralLink(walletAddress);
    const text = "Join the exclusive zaihash.xyz whitelist! Get early access to cutting-edge blockchain opportunities.";
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(link)}`;
    window.open(twitterUrl, '_blank');
  };

  const shareOnTelegram = (walletAddress: string) => {
    const link = getReferralLink(walletAddress);
    const text = "Join the exclusive zaihash.xyz whitelist! Get early access to cutting-edge blockchain opportunities.";
    const telegramUrl = `https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent(text)}`;
    window.open(telegramUrl, '_blank');
  };

  return {
    referralData,
    leaderboard,
    stats,
    getReferralCount,
    getReferralLink,
    copyReferralLink,
    shareOnTwitter,
    shareOnTelegram,
    refreshData,
  };
};
