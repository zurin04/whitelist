import { useAccount, useSignMessage, useDisconnect } from 'wagmi';
import { useConnectModal } from '@rainbow-me/rainbowkit';
import { createSignMessage } from '@/lib/web3';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';

export const useWallet = () => {
  const { address, isConnected } = useAccount();
  const { signMessage } = useSignMessage();
  const { disconnect } = useDisconnect();
  const { openConnectModal } = useConnectModal();
  const { toast } = useToast();
  const [isSigningIn, setIsSigningIn] = useState(false);

  const connectWallet = () => {
    if (openConnectModal) {
      openConnectModal();
    }
  };

  const signIn = async (): Promise<boolean> => {
    if (!address) {
      toast({
        title: "Wallet not connected",
        description: "Please connect your wallet first",
        variant: "destructive",
      });
      return false;
    }

    setIsSigningIn(true);
    try {
      const message = createSignMessage(address);
      await signMessage({ message });
      
      toast({
        title: "Successfully signed in",
        description: "Your wallet has been verified",
      });
      return true;
    } catch (error) {
      toast({
        title: "Sign in failed",
        description: "Please try signing the message again",
        variant: "destructive",
      });
      return false;
    } finally {
      setIsSigningIn(false);
    }
  };

  const disconnectWallet = () => {
    disconnect();
    toast({
      title: "Wallet disconnected",
      description: "Your wallet has been disconnected",
    });
  };

  return {
    address,
    isConnected,
    isSigningIn,
    connectWallet,
    signIn,
    disconnectWallet,
  };
};
