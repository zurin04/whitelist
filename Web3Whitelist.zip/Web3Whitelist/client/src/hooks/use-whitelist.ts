import { useState, useEffect } from 'react';
import { LocalStorage, LocalWhitelistEntry } from '@/lib/storage';
import { useToast } from '@/hooks/use-toast';

export const useWhitelist = () => {
  const [entries, setEntries] = useState<LocalWhitelistEntry[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    setEntries(LocalStorage.getWhitelistEntries());
  }, []);

  const addEntry = async (entry: Omit<LocalWhitelistEntry, 'timestamp'>) => {
    setIsLoading(true);
    try {
      // Check for duplicates
      if (LocalStorage.isEmailRegistered(entry.email)) {
        throw new Error('Email address is already registered');
      }

      if (LocalStorage.isWalletRegistered(entry.walletAddress)) {
        throw new Error('Wallet address is already registered');
      }

      // Prevent self-referrals
      if (entry.referrer && entry.referrer.toLowerCase() === entry.walletAddress.toLowerCase()) {
        throw new Error('You cannot refer yourself');
      }

      const newEntry: LocalWhitelistEntry = {
        ...entry,
        timestamp: Date.now(),
      };

      LocalStorage.addWhitelistEntry(newEntry);

      // Update referral count if there's a referrer
      if (entry.referrer) {
        LocalStorage.incrementReferralCount(entry.referrer);
      }

      setEntries(LocalStorage.getWhitelistEntries());
      
      toast({
        title: "Successfully joined whitelist!",
        description: "Welcome to the zaihash.xyz community",
      });

      return true;
    } catch (error) {
      toast({
        title: "Failed to join whitelist",
        description: error instanceof Error ? error.message : "Please try again",
        variant: "destructive",
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const getUserEntry = (walletAddress: string) => {
    return LocalStorage.getUserEntry(walletAddress);
  };

  const isUserWhitelisted = (walletAddress: string) => {
    return LocalStorage.isWalletRegistered(walletAddress);
  };

  return {
    entries,
    isLoading,
    addEntry,
    getUserEntry,
    isUserWhitelisted,
  };
};
