import { WhitelistEntry, ReferralData } from '@shared/schema';

export interface LocalWhitelistEntry {
  name: string;
  email: string;
  walletAddress: string;
  referrer?: string;
  timestamp: number;
}

export interface LocalReferralData {
  [walletAddress: string]: number;
}

export class LocalStorage {
  private static WHITELIST_KEY = 'web3_whitelist_entries';
  private static REFERRAL_KEY = 'web3_referral_data';

  static getWhitelistEntries(): LocalWhitelistEntry[] {
    try {
      const data = localStorage.getItem(this.WHITELIST_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  static getReferralData(): LocalReferralData {
    try {
      const data = localStorage.getItem(this.REFERRAL_KEY);
      return data ? JSON.parse(data) : {};
    } catch {
      return {};
    }
  }

  static addWhitelistEntry(entry: LocalWhitelistEntry): void {
    const entries = this.getWhitelistEntries();
    entries.push(entry);
    localStorage.setItem(this.WHITELIST_KEY, JSON.stringify(entries));
  }

  static updateReferralCount(walletAddress: string, count: number): void {
    const data = this.getReferralData();
    data[walletAddress] = count;
    localStorage.setItem(this.REFERRAL_KEY, JSON.stringify(data));
  }

  static incrementReferralCount(walletAddress: string): void {
    const data = this.getReferralData();
    data[walletAddress] = (data[walletAddress] || 0) + 1;
    localStorage.setItem(this.REFERRAL_KEY, JSON.stringify(data));
  }

  static isEmailRegistered(email: string): boolean {
    const entries = this.getWhitelistEntries();
    return entries.some(entry => entry.email.toLowerCase() === email.toLowerCase());
  }

  static isWalletRegistered(walletAddress: string): boolean {
    const entries = this.getWhitelistEntries();
    return entries.some(entry => entry.walletAddress.toLowerCase() === walletAddress.toLowerCase());
  }

  static getUserEntry(walletAddress: string): LocalWhitelistEntry | undefined {
    const entries = this.getWhitelistEntries();
    return entries.find(entry => entry.walletAddress.toLowerCase() === walletAddress.toLowerCase());
  }

  static getLeaderboard(): Array<{ walletAddress: string; referralCount: number }> {
    const data = this.getReferralData();
    return Object.entries(data)
      .map(([walletAddress, referralCount]) => ({ walletAddress, referralCount }))
      .sort((a, b) => b.referralCount - a.referralCount);
  }

  static getTotalStats() {
    const entries = this.getWhitelistEntries();
    const referralData = this.getReferralData();
    
    return {
      totalWhitelisted: entries.length,
      totalReferrals: Object.values(referralData).reduce((sum, count) => sum + count, 0),
      activeReferrers: Object.keys(referralData).length,
    };
  }
}
