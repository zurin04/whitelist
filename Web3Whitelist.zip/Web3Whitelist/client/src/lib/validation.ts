import { z } from 'zod';

export const whitelistFormSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters").max(100, "Name too long"),
  email: z.string().email("Invalid email format"),
  walletAddress: z.string().regex(/^0x[a-fA-F0-9]{40}$/, "Invalid wallet address format"),
});

export type WhitelistFormData = z.infer<typeof whitelistFormSchema>;

export const validateWhitelistForm = (data: WhitelistFormData) => {
  return whitelistFormSchema.safeParse(data);
};

export const anonymizeWallet = (walletAddress: string): string => {
  if (!walletAddress || walletAddress.length < 10) return walletAddress;
  return `${walletAddress.slice(0, 6)}...${walletAddress.slice(-4)}`;
};

export const isValidEthereumAddress = (address: string): boolean => {
  return /^0x[a-fA-F0-9]{40}$/.test(address);
};
