import { useEffect, useState } from 'react';
import { useAccount } from 'wagmi';
import { CheckCircle, Copy, Share2, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useWhitelist } from '@/hooks/use-whitelist';
import { useReferrals } from '@/hooks/use-referrals';
import { anonymizeWallet } from '@/lib/validation';

const Whitelist = () => {
  const { address } = useAccount();
  const { getUserEntry, isUserWhitelisted } = useWhitelist();
  const { getReferralCount, getReferralLink, copyReferralLink, shareOnTwitter, shareOnTelegram } = useReferrals();
  const [userEntry, setUserEntry] = useState<any>(null);
  const [isWhitelisted, setIsWhitelisted] = useState(false);

  useEffect(() => {
    if (address) {
      const entry = getUserEntry(address);
      setUserEntry(entry);
      setIsWhitelisted(isUserWhitelisted(address));
    }
  }, [address, getUserEntry, isUserWhitelisted]);

  if (!address) {
    return (
      <section className="min-h-screen pt-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-8 gradient-text">
              Whitelist Status
            </h2>
            <Alert className="glassmorphism border-neon-blue/30">
              <AlertDescription className="text-center text-lg">
                Please connect your wallet to view your whitelist status
              </AlertDescription>
            </Alert>
          </div>
        </div>
      </section>
    );
  }

  if (!isWhitelisted) {
    return (
      <section className="min-h-screen pt-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-8 gradient-text">
              Whitelist Status
            </h2>
            <Alert className="glassmorphism border-yellow-500/30">
              <AlertDescription className="text-center text-lg">
                You're not whitelisted yet. <a href="/" className="text-neon-blue hover:underline">Join now!</a>
              </AlertDescription>
            </Alert>
          </div>
        </div>
      </section>
    );
  }

  const referralCount = getReferralCount(address);
  const referralLink = getReferralLink(address);

  return (
    <section className="min-h-screen pt-20 pb-24">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 gradient-text">
            Whitelist Status
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Status Card */}
          <div className="glassmorphism rounded-2xl p-8">
            <div className="text-center">
              <div className="w-16 h-16 gradient-bg rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="text-2xl text-white" />
              </div>
              <h3 className="text-2xl font-bold text-neon-green mb-2">
                You're Whitelisted!
              </h3>
              <p className="text-gray-300">
                Congratulations! You have successfully joined our exclusive whitelist.
              </p>
            </div>

            {/* User Details */}
            {userEntry && (
              <div className="mt-8 space-y-4">
                <div className="flex justify-between items-center py-2 border-b border-gray-500/20">
                  <span className="text-gray-400">Name:</span>
                  <span className="text-white">{userEntry.name}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-gray-500/20">
                  <span className="text-gray-400">Email:</span>
                  <span className="text-white">{userEntry.email}</span>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-gray-400">Wallet:</span>
                  <span className="text-white font-mono">{anonymizeWallet(address)}</span>
                </div>
              </div>
            )}
          </div>

          {/* Referral Card */}
          <div className="glassmorphism rounded-2xl p-8">
            <h3 className="text-2xl font-bold mb-6 text-center">Your Referral Link</h3>
            
            <div className="space-y-4">
              <div className="bg-[hsl(var(--deep-space))]/50 rounded-lg p-4 border border-gray-500/20">
                <p className="text-sm text-gray-400 mb-2">Share this link to earn referral rewards:</p>
                <div className="flex items-center space-x-2">
                  <Input
                    readOnly
                    value={referralLink}
                    className="flex-1 bg-transparent text-sm text-gray-300 border-none outline-none p-0"
                  />
                  <Button
                    size="sm"
                    onClick={() => copyReferralLink(address)}
                    className="bg-neon-blue hover:bg-neon-blue/80 text-white"
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="text-center">
                <div className="text-3xl font-bold text-neon-purple mb-2">
                  {referralCount}
                </div>
                <p className="text-gray-400">Successful Referrals</p>
              </div>

              {/* Social Sharing */}
              <div className="flex justify-center space-x-4">
                <Button
                  onClick={() => shareOnTwitter(address)}
                  className="bg-blue-500 hover:bg-blue-600 text-white p-3"
                  size="sm"
                >
                  <Share2 className="w-4 h-4" />
                </Button>
                <Button
                  onClick={() => shareOnTelegram(address)}
                  className="bg-blue-400 hover:bg-blue-500 text-white p-3"
                  size="sm"
                >
                  <ExternalLink className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Whitelist;
