import LeaderboardTable from '@/components/leaderboard-table';

const Leaderboard = () => {
  return (
    <section className="min-h-screen pt-20 pb-24">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 gradient-text">
            Referral Leaderboard
          </h2>
          <p className="text-xl text-gray-300">
            Top performers in our community referral program
          </p>
        </div>

        <LeaderboardTable />
      </div>
    </section>
  );
};

export default Leaderboard;
