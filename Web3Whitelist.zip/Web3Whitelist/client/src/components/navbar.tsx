import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { ConnectButton } from '@rainbow-me/rainbowkit';
import { useAccount } from 'wagmi';
import { Button } from '@/components/ui/button';
import { Menu, X } from 'lucide-react';
import { anonymizeWallet } from '@/lib/validation';

const Navbar = () => {
  const [location] = useLocation();
  const { address } = useAccount();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { path: '/', label: 'Home' },
    { path: '/whitelist', label: 'Whitelist' },
    { path: '/leaderboard', label: 'Leaderboard' },
  ];

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <>
      <nav className="sticky top-0 z-50 glassmorphism border-b border-gray-500/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center space-x-8">
              <Link href="/">
                <span className="text-xl font-bold gradient-text cursor-pointer">
                  zaihash
                </span>
              </Link>

              {/* Desktop Navigation */}
              <div className="hidden md:flex space-x-6">
                {navItems.map(({ path, label }) => (
                  <Link key={path} href={path}>
                    <span
                      className={`transition-all duration-300 hover:text-neon-blue hover:underline underline-offset-4 cursor-pointer ${
                        isActive(path) ? 'text-neon-blue' : 'text-gray-300'
                      }`}
                    >
                      {label}
                    </span>
                  </Link>
                ))}
              </div>
            </div>

            {/* Wallet Connection */}
            <div className="flex items-center space-x-4">
              {address && (
                <div className="hidden sm:block glassmorphism rounded-lg px-3 py-1 text-sm text-gray-300">
                  {anonymizeWallet(address)}
                </div>
              )}
              <div className="hidden md:block">
                <ConnectButton />
              </div>
              
              {/* Mobile menu button */}
              <Button
                variant="ghost"
                size="sm"
                className="md:hidden"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                {isMobileMenuOpen ? <X /> : <Menu />}
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Navigation */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-40 bg-black/50" onClick={() => setIsMobileMenuOpen(false)}>
          <div className="fixed top-16 left-0 right-0 glassmorphism border-b border-gray-500/30 p-4">
            <div className="flex flex-col space-y-4">
              {navItems.map(({ path, label }) => (
                <Link key={path} href={path}>
                  <span
                    className={`block transition-all duration-300 hover:text-neon-blue cursor-pointer ${
                      isActive(path) ? 'text-neon-blue' : 'text-gray-300'
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {label}
                  </span>
                </Link>
              ))}
              <div className="pt-4 border-t border-gray-500/30">
                <ConnectButton />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden fixed bottom-4 left-4 right-4 z-50">
        <div className="glassmorphism rounded-2xl p-4">
          <div className="flex justify-around">
            {navItems.map(({ path, label }) => (
              <Link key={path} href={path}>
                <button
                  className={`flex flex-col items-center space-y-1 transition-colors ${
                    isActive(path) ? 'text-neon-blue' : 'text-gray-400 hover:text-neon-blue'
                  }`}
                >
                  <div className="text-xl">
                    {label === 'Home' && '🏠'}
                    {label === 'Whitelist' && '📝'}
                    {label === 'Leaderboard' && '🏆'}
                  </div>
                  <span className="text-xs">{label}</span>
                </button>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default Navbar;
